#ifndef YOLIES_HEAD_N_FOOT_H
#define YOLIES_HEAD_N_FOOT_H

#include "std_lib_facilities.h"

void yoliesProgramHeader();
void yoliesProgramFooter();
void displayExplanation();

#endif //YOLIES_HEAD_N_FOOT_H Included
